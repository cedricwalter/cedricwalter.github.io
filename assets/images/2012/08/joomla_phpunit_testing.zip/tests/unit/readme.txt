from https://github.com/joomla/joomla-cms/tree/master/tests/unit

You don't need to include/require anything PHPUnit related since (at least) PHPUnit 3.6 any more and you can't include that file because it doesn't exist any more in the distribution.

The phpunit runner will take care of bootstrapping everything that is needed by PHPUnit :)