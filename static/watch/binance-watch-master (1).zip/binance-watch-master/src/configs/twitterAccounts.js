/**
 * Default twitter accounts for news
 */
export default [
  '1Foxcom',
  'coinbase',
  'binance',
  'HuobiGlobal',
  'YobitExchange',
  'BittrexExchange',
  'Coinsquare',
  'hitbtc',
  'Cryptopia_NZ',
  'Bitstamp',
  'bitfinex',
  'krakenfx',
  'coindesk',
  'Cointelegraph',
];
